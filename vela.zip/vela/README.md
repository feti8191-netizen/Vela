# Vela

A modern programming language with unique syntax — implemented from scratch in C++17.

```bash
make
./vela examples/01_hello.vel
./vela                  # REPL
./vela --tokens file.vel
```

## Examples (every feature)

| File | Feature |
|------|---------|
| `01_hello.vel` | print, comments |
| `02_bindings.vel` | `:=` immutable, `<-` mutable |
| `03_functions.vel` | functions, defaults, named args |
| `04_lambdas_pipe.vel` | lambdas, `\|>` pipe |
| `05_control.vel` | when/else, skip, bail |
| `06_until_unless.vel` | until, unless |
| `07_ranges.vel` | `to` / `through` / `by` |
| `08_arrays_slices.vel` | arrays, slices, spread, slice assign |
| `09_destructure.vel` | array/map/for destructuring |
| `10_maps.vel` | maps, fields, `?.`, `??` |
| `11_records.vel` | record, new, methods via `self` |
| `12_enums_match.vel` | enum, match, guards, patterns |
| `13_errors_defer.vel` | throw, try/catch, defer |
| `14_closures.vel` | closures, recursion |
| `15_math.vel` | math stdlib |
| `16_collections.vel` | map/filter/reduce/… helpers |
| `17_strings.vel` | interpolation, string ops, regex |
| `18_sets.vel` | `#{…}` sets |
| `19_json_files.vel` | JSON + file I/O |
| `20_bitwise_types.vel` | bitwise, `is`, assert, tuples |
| `21_modules.vel` | import / import as |
| `22_operators.vel` | arithmetic, logic, ternary |

## Quick syntax

```vela
x := 10;              // immutable
y <- 20;              // mutable
add(a, b := 1) ==> a + b;
print(3 |> add(2));
when x > 0 { print("pos"); }
repeat i from 0 through 5 { print(i); }
record Point { x: num, y: num, }
p := new Point{x: 1, y: 2};
match v { 0 => "zero", [h, ...t] => "list", _ => "other" }
try { throw "nope"; } catch e { print(e); }
import "utils_mod.vel" as u;
```
